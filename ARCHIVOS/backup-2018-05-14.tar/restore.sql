--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_usuario_key;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY public.tutorias DROP CONSTRAINT tutorias_pkey;
ALTER TABLE ONLY public.produccion DROP CONSTRAINT produccion_pkey;
ALTER TABLE ONLY public.formacion DROP CONSTRAINT formacion_pkey;
ALTER TABLE ONLY public.carga DROP CONSTRAINT carga_pkey;
ALTER TABLE public.usuario ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tutorias ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.produccion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formacion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.carga ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.usuario_id_seq;
DROP TABLE public.usuario;
DROP SEQUENCE public.tutorias_id_seq;
DROP TABLE public.tutorias;
DROP SEQUENCE public.produccion_id_seq;
DROP TABLE public.produccion;
DROP SEQUENCE public.formacion_id_seq;
DROP TABLE public.formacion;
DROP SEQUENCE public.carga_id_seq;
DROP TABLE public.carga;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: carga; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE carga (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    nombre character varying(40) NOT NULL,
    fecha_inicio timestamp without time zone NOT NULL,
    fecha_fin timestamp without time zone NOT NULL,
    programa character varying(40) NOT NULL,
    horas_semana integer NOT NULL
);


ALTER TABLE carga OWNER TO postgres;

--
-- Name: carga_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE carga_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE carga_id_seq OWNER TO postgres;

--
-- Name: carga_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE carga_id_seq OWNED BY carga.id;


--
-- Name: formacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formacion (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    grado character varying(40) NOT NULL,
    nombre character varying(40) NOT NULL,
    institucion character varying(40) NOT NULL,
    fecha_inicio timestamp without time zone NOT NULL,
    fecha_fin timestamp without time zone NOT NULL,
    fecha_obtencion timestamp without time zone NOT NULL,
    cedula character varying(15) NOT NULL
);


ALTER TABLE formacion OWNER TO postgres;

--
-- Name: formacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formacion_id_seq OWNER TO postgres;

--
-- Name: formacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formacion_id_seq OWNED BY formacion.id;


--
-- Name: produccion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE produccion (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    tipo character varying(40) NOT NULL,
    titulo character varying(40) NOT NULL,
    fecha timestamp without time zone NOT NULL,
    autores character varying(80) NOT NULL,
    institucion character varying(40) NOT NULL,
    num_registro character varying(15) NOT NULL
);


ALTER TABLE produccion OWNER TO postgres;

--
-- Name: produccion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE produccion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE produccion_id_seq OWNER TO postgres;

--
-- Name: produccion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE produccion_id_seq OWNED BY produccion.id;


--
-- Name: tutorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tutorias (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    nombre_alumno character varying(40) NOT NULL,
    fecha_inicio timestamp without time zone NOT NULL,
    fecha_fin timestamp without time zone NOT NULL,
    horas_semana integer NOT NULL
);


ALTER TABLE tutorias OWNER TO postgres;

--
-- Name: tutorias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tutorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tutorias_id_seq OWNER TO postgres;

--
-- Name: tutorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tutorias_id_seq OWNED BY tutorias.id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usuario (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    contrasena character varying(40) NOT NULL,
    nombre character varying(40),
    apellido character varying(40),
    domicilio character varying(40),
    ciudad character varying(40),
    telefono character varying(15),
    correo character varying(40),
    nombre_dependiente_1 character varying(80),
    edad_dependiente_1 integer,
    nombre_dependiente_2 character varying(80),
    edad_dependiente_2 integer,
    foto character varying(100) DEFAULT 'default'::character varying NOT NULL
);


ALTER TABLE usuario OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usuario_id_seq OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usuario_id_seq OWNED BY usuario.id;


--
-- Name: carga id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY carga ALTER COLUMN id SET DEFAULT nextval('carga_id_seq'::regclass);


--
-- Name: formacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formacion ALTER COLUMN id SET DEFAULT nextval('formacion_id_seq'::regclass);


--
-- Name: produccion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produccion ALTER COLUMN id SET DEFAULT nextval('produccion_id_seq'::regclass);


--
-- Name: tutorias id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tutorias ALTER COLUMN id SET DEFAULT nextval('tutorias_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario ALTER COLUMN id SET DEFAULT nextval('usuario_id_seq'::regclass);


--
-- Data for Name: carga; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY carga (id, usuario, nombre, fecha_inicio, fecha_fin, programa, horas_semana) FROM stdin;
\.
COPY carga (id, usuario, nombre, fecha_inicio, fecha_fin, programa, horas_semana) FROM '$$PATH$$/2841.dat';

--
-- Data for Name: formacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formacion (id, usuario, grado, nombre, institucion, fecha_inicio, fecha_fin, fecha_obtencion, cedula) FROM stdin;
\.
COPY formacion (id, usuario, grado, nombre, institucion, fecha_inicio, fecha_fin, fecha_obtencion, cedula) FROM '$$PATH$$/2837.dat';

--
-- Data for Name: produccion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY produccion (id, usuario, tipo, titulo, fecha, autores, institucion, num_registro) FROM stdin;
\.
COPY produccion (id, usuario, tipo, titulo, fecha, autores, institucion, num_registro) FROM '$$PATH$$/2839.dat';

--
-- Data for Name: tutorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tutorias (id, usuario, nombre_alumno, fecha_inicio, fecha_fin, horas_semana) FROM stdin;
\.
COPY tutorias (id, usuario, nombre_alumno, fecha_inicio, fecha_fin, horas_semana) FROM '$$PATH$$/2843.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usuario (id, usuario, contrasena, nombre, apellido, domicilio, ciudad, telefono, correo, nombre_dependiente_1, edad_dependiente_1, nombre_dependiente_2, edad_dependiente_2, foto) FROM stdin;
\.
COPY usuario (id, usuario, contrasena, nombre, apellido, domicilio, ciudad, telefono, correo, nombre_dependiente_1, edad_dependiente_1, nombre_dependiente_2, edad_dependiente_2, foto) FROM '$$PATH$$/2835.dat';

--
-- Name: carga_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('carga_id_seq', 2, true);


--
-- Name: formacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formacion_id_seq', 5, true);


--
-- Name: produccion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('produccion_id_seq', 4, true);


--
-- Name: tutorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tutorias_id_seq', 2, true);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usuario_id_seq', 4, true);


--
-- Name: carga carga_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY carga
    ADD CONSTRAINT carga_pkey PRIMARY KEY (id);


--
-- Name: formacion formacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formacion
    ADD CONSTRAINT formacion_pkey PRIMARY KEY (id);


--
-- Name: produccion produccion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produccion
    ADD CONSTRAINT produccion_pkey PRIMARY KEY (id);


--
-- Name: tutorias tutorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tutorias
    ADD CONSTRAINT tutorias_pkey PRIMARY KEY (id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: usuario usuario_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_usuario_key UNIQUE (usuario);


--
-- PostgreSQL database dump complete
--

