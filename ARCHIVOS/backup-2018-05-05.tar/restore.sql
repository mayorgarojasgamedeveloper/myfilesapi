--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_usuario_key;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY public.reporte_4 DROP CONSTRAINT reporte_4_pkey;
ALTER TABLE ONLY public.reporte_3 DROP CONSTRAINT reporte_3_pkey;
ALTER TABLE ONLY public.reporte_2 DROP CONSTRAINT reporte_2_pkey;
ALTER TABLE ONLY public.reporte_1 DROP CONSTRAINT reporte_1_pkey;
ALTER TABLE ONLY public.proyecto DROP CONSTRAINT proyecto_pkey;
ALTER TABLE ONLY public.log DROP CONSTRAINT log_pkey;
ALTER TABLE ONLY public.lineainovadora DROP CONSTRAINT lineainovadora_pkey;
ALTER TABLE ONLY public.informetecnico DROP CONSTRAINT informetecnico_pkey;
ALTER TABLE public.usuario ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.reporte_4 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.reporte_3 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.reporte_2 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.reporte_1 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proyecto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lineainovadora ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.informetecnico ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.usuario_id_seq;
DROP TABLE public.usuario;
DROP SEQUENCE public.reporte_4_id_seq;
DROP TABLE public.reporte_4;
DROP SEQUENCE public.reporte_3_id_seq;
DROP TABLE public.reporte_3;
DROP SEQUENCE public.reporte_2_id_seq;
DROP TABLE public.reporte_2;
DROP SEQUENCE public.reporte_1_id_seq;
DROP TABLE public.reporte_1;
DROP SEQUENCE public.proyecto_id_seq;
DROP TABLE public.proyecto;
DROP SEQUENCE public.log_id_seq;
DROP TABLE public.log;
DROP SEQUENCE public.lineainovadora_id_seq;
DROP TABLE public.lineainovadora;
DROP SEQUENCE public.informetecnico_id_seq;
DROP TABLE public.informetecnico;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: informetecnico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE informetecnico (
    id integer NOT NULL,
    usuario character varying(20),
    tipo smallint NOT NULL,
    nombre character varying(50) NOT NULL,
    autores character varying(200),
    fecha timestamp without time zone,
    linea character varying(50) NOT NULL,
    subtipo smallint NOT NULL,
    dependencia character varying(40) NOT NULL
);


ALTER TABLE informetecnico OWNER TO postgres;

--
-- Name: informetecnico_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE informetecnico_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE informetecnico_id_seq OWNER TO postgres;

--
-- Name: informetecnico_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE informetecnico_id_seq OWNED BY informetecnico.id;


--
-- Name: lineainovadora; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE lineainovadora (
    id integer NOT NULL,
    usuario character varying(20),
    tipo smallint NOT NULL,
    linea character varying(50) NOT NULL
);


ALTER TABLE lineainovadora OWNER TO postgres;

--
-- Name: lineainovadora_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE lineainovadora_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lineainovadora_id_seq OWNER TO postgres;

--
-- Name: lineainovadora_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE lineainovadora_id_seq OWNED BY lineainovadora.id;


--
-- Name: log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE log (
    id integer NOT NULL,
    ip character varying(20),
    accion character varying(50),
    fecha timestamp without time zone
);


ALTER TABLE log OWNER TO postgres;

--
-- Name: log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE log_id_seq OWNER TO postgres;

--
-- Name: log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE log_id_seq OWNED BY log.id;


--
-- Name: proyecto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE proyecto (
    id integer NOT NULL,
    usuario character varying(20),
    tipo smallint NOT NULL,
    nombre character varying(50) NOT NULL,
    fecha_inicio timestamp without time zone NOT NULL,
    fecha_fin timestamp without time zone NOT NULL,
    colaboradores character varying(200),
    instituciones character varying(200)
);


ALTER TABLE proyecto OWNER TO postgres;

--
-- Name: proyecto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE proyecto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE proyecto_id_seq OWNER TO postgres;

--
-- Name: proyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE proyecto_id_seq OWNED BY proyecto.id;


--
-- Name: reporte_1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE reporte_1 (
    id integer NOT NULL,
    usuario character varying(20),
    tipo smallint NOT NULL,
    nombre character varying(50) NOT NULL,
    autores character varying(200),
    fecha timestamp without time zone,
    linea character varying(50) NOT NULL,
    subtipo smallint NOT NULL,
    issn character varying(20) NOT NULL,
    nom_revista character varying(40) NOT NULL
);


ALTER TABLE reporte_1 OWNER TO postgres;

--
-- Name: reporte_1_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reporte_1_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reporte_1_id_seq OWNER TO postgres;

--
-- Name: reporte_1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reporte_1_id_seq OWNED BY reporte_1.id;


--
-- Name: reporte_2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE reporte_2 (
    id integer NOT NULL,
    usuario character varying(20),
    tipo smallint NOT NULL,
    nombre character varying(50) NOT NULL,
    autores character varying(200),
    fecha timestamp without time zone,
    linea character varying(50) NOT NULL,
    subtipo smallint NOT NULL,
    isbn character varying(20) NOT NULL,
    nom_libro character varying(40) NOT NULL
);


ALTER TABLE reporte_2 OWNER TO postgres;

--
-- Name: reporte_2_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reporte_2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reporte_2_id_seq OWNER TO postgres;

--
-- Name: reporte_2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reporte_2_id_seq OWNED BY reporte_2.id;


--
-- Name: reporte_3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE reporte_3 (
    id integer NOT NULL,
    usuario character varying(20),
    tipo smallint NOT NULL,
    nombre character varying(50) NOT NULL,
    autores character varying(200),
    fecha timestamp without time zone,
    linea character varying(50) NOT NULL,
    subtipo smallint NOT NULL,
    no_registro character varying(20) NOT NULL
);


ALTER TABLE reporte_3 OWNER TO postgres;

--
-- Name: reporte_3_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reporte_3_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reporte_3_id_seq OWNER TO postgres;

--
-- Name: reporte_3_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reporte_3_id_seq OWNED BY reporte_3.id;


--
-- Name: reporte_4; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE reporte_4 (
    id integer NOT NULL,
    usuario character varying(20),
    tipo smallint NOT NULL,
    nombre character varying(50) NOT NULL,
    fecha_inicio timestamp without time zone NOT NULL,
    fecha_fin timestamp without time zone NOT NULL,
    nombre_empresa character varying(80),
    nombre_alumno character varying(80)
);


ALTER TABLE reporte_4 OWNER TO postgres;

--
-- Name: reporte_4_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reporte_4_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reporte_4_id_seq OWNER TO postgres;

--
-- Name: reporte_4_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reporte_4_id_seq OWNED BY reporte_4.id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usuario (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    contrasena character varying(20) NOT NULL,
    nombre character varying(40),
    apellidop character varying(40),
    apellidom character varying(40),
    correo character varying(50),
    curriculum character varying(400),
    foto character varying(100) DEFAULT 'default'::character varying NOT NULL,
    permisos boolean DEFAULT false NOT NULL
);


ALTER TABLE usuario OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usuario_id_seq OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usuario_id_seq OWNED BY usuario.id;


--
-- Name: informetecnico id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY informetecnico ALTER COLUMN id SET DEFAULT nextval('informetecnico_id_seq'::regclass);


--
-- Name: lineainovadora id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lineainovadora ALTER COLUMN id SET DEFAULT nextval('lineainovadora_id_seq'::regclass);


--
-- Name: log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY log ALTER COLUMN id SET DEFAULT nextval('log_id_seq'::regclass);


--
-- Name: proyecto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proyecto ALTER COLUMN id SET DEFAULT nextval('proyecto_id_seq'::regclass);


--
-- Name: reporte_1 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_1 ALTER COLUMN id SET DEFAULT nextval('reporte_1_id_seq'::regclass);


--
-- Name: reporte_2 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_2 ALTER COLUMN id SET DEFAULT nextval('reporte_2_id_seq'::regclass);


--
-- Name: reporte_3 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_3 ALTER COLUMN id SET DEFAULT nextval('reporte_3_id_seq'::regclass);


--
-- Name: reporte_4 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_4 ALTER COLUMN id SET DEFAULT nextval('reporte_4_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario ALTER COLUMN id SET DEFAULT nextval('usuario_id_seq'::regclass);


--
-- Data for Name: informetecnico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY informetecnico (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, dependencia) FROM stdin;
\.
COPY informetecnico (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, dependencia) FROM '$$PATH$$/2886.dat';

--
-- Data for Name: lineainovadora; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lineainovadora (id, usuario, tipo, linea) FROM stdin;
\.
COPY lineainovadora (id, usuario, tipo, linea) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY log (id, ip, accion, fecha) FROM stdin;
\.
COPY log (id, ip, accion, fecha) FROM '$$PATH$$/2872.dat';

--
-- Data for Name: proyecto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY proyecto (id, usuario, tipo, nombre, fecha_inicio, fecha_fin, colaboradores, instituciones) FROM stdin;
\.
COPY proyecto (id, usuario, tipo, nombre, fecha_inicio, fecha_fin, colaboradores, instituciones) FROM '$$PATH$$/2878.dat';

--
-- Data for Name: reporte_1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reporte_1 (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, issn, nom_revista) FROM stdin;
\.
COPY reporte_1 (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, issn, nom_revista) FROM '$$PATH$$/2882.dat';

--
-- Data for Name: reporte_2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reporte_2 (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, isbn, nom_libro) FROM stdin;
\.
COPY reporte_2 (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, isbn, nom_libro) FROM '$$PATH$$/2888.dat';

--
-- Data for Name: reporte_3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reporte_3 (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, no_registro) FROM stdin;
\.
COPY reporte_3 (id, usuario, tipo, nombre, autores, fecha, linea, subtipo, no_registro) FROM '$$PATH$$/2884.dat';

--
-- Data for Name: reporte_4; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reporte_4 (id, usuario, tipo, nombre, fecha_inicio, fecha_fin, nombre_empresa, nombre_alumno) FROM stdin;
\.
COPY reporte_4 (id, usuario, tipo, nombre, fecha_inicio, fecha_fin, nombre_empresa, nombre_alumno) FROM '$$PATH$$/2880.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usuario (id, usuario, contrasena, nombre, apellidop, apellidom, correo, curriculum, foto, permisos) FROM stdin;
\.
COPY usuario (id, usuario, contrasena, nombre, apellidop, apellidom, correo, curriculum, foto, permisos) FROM '$$PATH$$/2874.dat';

--
-- Name: informetecnico_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('informetecnico_id_seq', 3, true);


--
-- Name: lineainovadora_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('lineainovadora_id_seq', 7, true);


--
-- Name: log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('log_id_seq', 3, true);


--
-- Name: proyecto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('proyecto_id_seq', 5, true);


--
-- Name: reporte_1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reporte_1_id_seq', 2, true);


--
-- Name: reporte_2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reporte_2_id_seq', 3, true);


--
-- Name: reporte_3_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reporte_3_id_seq', 3, true);


--
-- Name: reporte_4_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reporte_4_id_seq', 4, true);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usuario_id_seq', 80, true);


--
-- Name: informetecnico informetecnico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY informetecnico
    ADD CONSTRAINT informetecnico_pkey PRIMARY KEY (id);


--
-- Name: lineainovadora lineainovadora_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lineainovadora
    ADD CONSTRAINT lineainovadora_pkey PRIMARY KEY (id);


--
-- Name: log log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY log
    ADD CONSTRAINT log_pkey PRIMARY KEY (id);


--
-- Name: proyecto proyecto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT proyecto_pkey PRIMARY KEY (id);


--
-- Name: reporte_1 reporte_1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_1
    ADD CONSTRAINT reporte_1_pkey PRIMARY KEY (id);


--
-- Name: reporte_2 reporte_2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_2
    ADD CONSTRAINT reporte_2_pkey PRIMARY KEY (id);


--
-- Name: reporte_3 reporte_3_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_3
    ADD CONSTRAINT reporte_3_pkey PRIMARY KEY (id);


--
-- Name: reporte_4 reporte_4_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reporte_4
    ADD CONSTRAINT reporte_4_pkey PRIMARY KEY (id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: usuario usuario_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_usuario_key UNIQUE (usuario);


--
-- PostgreSQL database dump complete
--

